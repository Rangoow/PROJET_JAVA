
import java.io.IOException;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author noees
 */

public class Test {
    static Player player;
    public static void main(String[] args) throws IOException{
        
        player = new Player("test");
        //start the game
        //GameLogic.startGame();
        Data.createDataFile();
        Data.saveData(player.getName(), "bla", 0);
    }
}
